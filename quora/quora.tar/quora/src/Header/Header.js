import React from 'react'
import MyNavbar from './navbar/navbar'
class Header extends React.Component{
    render(){
        return(
            <div>
              <MyNavbar/>
            </div>
        )
    }
}

export default Header;