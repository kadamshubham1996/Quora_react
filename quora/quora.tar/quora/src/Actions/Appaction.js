import Reflux from 'reflux';


const AppActions=Reflux.createActions([
    'showLoginPopup',
    'showCancelPopup',
    'Login',
    'showRegistorPopup'
]);
export default AppActions