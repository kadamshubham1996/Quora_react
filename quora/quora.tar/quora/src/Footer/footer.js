import React from 'react'

class Footer extends React.Component{
    render(){
        return(
            <div>Header</div>
        )
    }
}

export default Footer;